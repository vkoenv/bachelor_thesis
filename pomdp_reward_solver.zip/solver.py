import stormpy
from pomdpdrngurobi_sjabove_robust_interval_rew import QcqpOptions
from pomdpdrngurobi_sjabove_robust_interval_rew import QcqpSolver_affine_simple_fun
from pomdpdrngurobi_sjabove_robust_interval_rew import find_rew0_states


def solve_prism_pomdp(prism_file, formula_str, threshold, mem_value=1, print_policy=False):
    print("preparing model")

    prism_program = stormpy.parse_prism_program(prism_file)
    opts = stormpy.DirectEncodingParserOptions()
    opts.build_choice_labels = True
    properties = stormpy.parse_properties_for_prism_program(formula_str, prism_program)
    pomdp = stormpy.build_model(prism_program,properties)
    pomdp = stormpy.pomdp.make_canonic(pomdp)
    memory_builder = stormpy.pomdp.PomdpMemoryBuilder()
    memory = memory_builder.build(stormpy.pomdp.PomdpMemoryPattern.selective_counter, mem_value)
    # apply the memory onto the POMDP to get the cartesian product
    pomdp = stormpy.pomdp.unfold_memory(pomdp, memory)
    print("Number of pomdp states before simple:", pomdp.nr_states)
    print("Number of transitions: {}".format(pomdp.nr_transitions))
    # make the POMDP simple. This step is optional but often beneficial
    pomdp = stormpy.pomdp.make_simple(pomdp)
    print("Number of pomdp states after simple:", pomdp.nr_states)
    print("Number of transitions: {}".format(pomdp.nr_transitions))
    # apply the unknown FSC to obtain a pmc from the POMDP
    pmc = stormpy.pomdp.apply_unknown_fsc(pomdp, stormpy.pomdp.PomdpFscApplicationMode.simple_linear)
    print("Number of pomdp states after simple", pmc.nr_states)
    print("Number of transitions: {}".format(pmc.nr_transitions))
    print(pmc)
    print("applied pmc")
    path_pmc = "export_" + str(mem_value) + "_mem_" + prism_file
    print(path_pmc)
    #stormpy.export_parametric_to_drn(pmc, path_pmc)
    stormpy.export_to_drn(pmc, path_pmc)
    print("start solving\n")
    result = solve_nominal_pomdp(path_pmc,formula_str,threshold)
    print(result.value_at_initial)
    if print_policy:
        print(result.parameter_values)


def solve_prism_pomdp_reward(prism_file, formula_str, threshold, mem_value=1, print_policy=False):
    print("preparing model")

    prism_program = stormpy.parse_prism_program(prism_file)
    opts = stormpy.DirectEncodingParserOptions()
    opts.build_choice_labels = True
    properties = stormpy.parse_properties_for_prism_program(formula_str, prism_program)
    pomdp = stormpy.build_model(prism_program,properties)
    pomdp = stormpy.pomdp.make_canonic(pomdp)
    memory_builder = stormpy.pomdp.PomdpMemoryBuilder()
    memory = memory_builder.build(stormpy.pomdp.PomdpMemoryPattern.selective_counter, mem_value)
    # apply the memory onto the POMDP to get the cartesian product
    pomdp = stormpy.pomdp.unfold_memory(pomdp, memory)
    print("Number of pomdp states before simple:", pomdp.nr_states)
    print("Number of transitions: {}".format(pomdp.nr_transitions))
    # make the POMDP simple. This step is optional but often beneficial
    pomdp = stormpy.pomdp.make_simple(pomdp)
    print("Number of pomdp states after simple:", pomdp.nr_states)
    print("Number of transitions: {}".format(pomdp.nr_transitions))
    # apply the unknown FSC to obtain a pmc from the POMDP
    pmc = stormpy.pomdp.apply_unknown_fsc(pomdp, stormpy.pomdp.PomdpFscApplicationMode.simple_linear)
    print("Number of pomdp states after simple", pmc.nr_states)
    print("Number of transitions: {}".format(pmc.nr_transitions))
    print(pmc)
    print("applied pmc")
    path_pmc = "export_" + str(mem_value) + "_mem_" + prism_file
    print(path_pmc)
    #stormpy.export_parametric_to_drn(pmc, path_pmc)
    stormpy.export_to_drn(pmc, path_pmc)
    print("start solving\n")
    result = solve_nominal_pomdp_reward(path_pmc,formula_str,threshold)
    print(result.value_at_initial)
    if print_policy:
        print(result.parameter_values)
        
        
        
def solve_nominal_pomdp(pmc_path, formula_str, threshold, direction="below", maxiter=100, silent=False):
    print("Building model from {}".format(pmc_path))
    pmc = stormpy.build_parametric_model_from_drn(pmc_path)
    fsc_parameters = pmc.collect_probability_parameters()
    print("number of pomdp parameters={}".format(len(fsc_parameters)))
    print("number of pmc states={}".format(pmc.nr_states))

    properties = stormpy.parse_properties(formula_str)

    # compute prob01max states for any policy
    prob0E, prob1A = stormpy.prob01max_states(pmc, properties[0].raw_formula.subformula)
    # solver parameters
    options = QcqpOptions(mu=1e4, maxiter=maxiter, graph_epsilon=1e-2, silent=silent)

    # run uncertain POMDP solver without uncertainty
    solver = QcqpSolver_affine_simple_fun()
    pomdp_parameters = set()
    intervals = {}
    items = {}
    result = solver.run(pmc, fsc_parameters, pomdp_parameters, properties, prob0E, prob1A, threshold, direction,
                        options, intervals, items, True)

    print("SOLVED")
    print("number of iterations={}".format(solver.iterations))
    print("solver time={}".format(solver.solver_timer))
    print("value at initial state={}".format(result.value_at_initial))

    return result


def solve_nominal_pomdp_reward(pmc_path, formula_str, threshold, direction="below", maxiter=100, silent=False):
    print("Building model from {}".format(pmc_path))
    pmc = stormpy.build_parametric_model_from_drn(pmc_path)
    fsc_parameters = pmc.collect_probability_parameters()
    print("number of pomdp parameters={}".format(len(fsc_parameters)))
    print("number of pmc states={}".format(pmc.nr_states))

    properties = stormpy.parse_properties(formula_str)

    # compute prob01max states for any policy
    
    rew0E = find_rew0_states(properties[0], pmc)
    reward_name = list(pmc.reward_models.keys())[0]
    
    #threshold = 1e-4
    direction = "below"  # can be "below" or "above"
    
    # solver parameters
    options = QcqpOptions(mu=1e4, maxiter=1000, graph_epsilon=2e-2, silent=silent)
    
    # run uncertain POMDP solver without uncertainty
    solver = QcqpSolver_affine_simple_fun()
    pomdp_parameters = set()
    intervals = {}
    items = {}
    result = solver.run(pmc,  fsc_parameters, pomdp_parameters,properties, rew0E, reward_name,threshold, direction, options,intervals,items,True)

    print("\n\nSOLVED\n")
    print("number of iterations={}".format(solver.iterations))
    print("solver time={}".format(solver.solver_timer))
    print("value at initial state={}".format(result.value_at_initial))

    return result


if __name__ == '__main__':
    solve_prism_pomdp_reward("grid.prism", "Rmin=?[F \"goal\"]",0.0)
